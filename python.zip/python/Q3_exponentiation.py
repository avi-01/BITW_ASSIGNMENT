import math

number = float(input("Enter the number: "))

expVal = math.exp(number)

print("Exponentiation of the number {} is {}".format(number,expVal))