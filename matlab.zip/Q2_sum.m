a = input("Enter the first number");
b = input("Enter the second number");
sum = a + b;
fprintf('The sum = %d\n',sum);