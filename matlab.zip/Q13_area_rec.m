length = input("Enter the length of the rectangle");
breadth = input("Enter the breadth of the rectangle");

area = length*breadth;

fprintf("The are of the rectangle %dx%d = %d",length,breadth,area);