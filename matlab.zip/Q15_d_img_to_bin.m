img=imread('rice.png');
threshold = 100;
img = img > threshold;
imshow(img);