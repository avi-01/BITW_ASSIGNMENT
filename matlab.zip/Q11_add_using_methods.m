classdef Q11_add_using_methods
    
    properties
        sum
    end
    
    methods
        function obj = add(inputArg1,inputArg2)
            obj.sum = inputArg1 + inputArg2;
        end
    end
end
